# Discord 多功能機器人 🤖

## 功能
- `!ping` 測試延遲
- `!help` 顯示指令
- `!roll` 擲骰子
- `!draw` 抽籤
- 成員加入歡迎

## 使用方法
1. 建立 `.env`，填入你的 Token
2. 安裝套件 `npm install`
3. 啟動 `npm start`